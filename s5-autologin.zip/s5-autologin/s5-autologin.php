<?php
/*
   Plugin Name: S5 Autologin
   Plugin URI: http://wordpress.org/extend/plugins/s5-autologin/
   Version: 0.1
   Author: 
   Description: s5 Autologin
   Text Domain: s5-autologin
   License: GPLv3
  */

if ( !function_exists( 'add_action' ) ) {
  echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
  exit;
}

add_action( 'init', 's5_autologin');

function s5_autologin() {
    $username='admin';
    if (!defined('S5_APP_TOKEN')) {
     include ( plugin_dir_path( __FILE__ ) . '../../../wp-config.php');
    } 
    $token=S5_APP_TOKEN;

    if ( ! is_admin() || is_user_logged_in() ) return;

    if ( ! isset( $_GET['s5token'] ) || $_GET['s5token'] !== $token) return;
    //if ( ! isset( $_GET['s5token'] ) ) return;

    $user = get_user_by( 'login', $username );
    wp_set_auth_cookie($user->ID) ;

    if ( is_wp_error( $user ) )
      echo $user->get_error_message();

    wp_redirect( esc_url( get_admin_url() ) ); 
    exit;
}

